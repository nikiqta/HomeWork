const express = require('express');
const serve   = require('express-static');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const port = 3000;

app.use(express.static(path.join(__dirname, 'public')));
//app.use(serve(__dirname + '/public'));

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

require('./config/db')
    .then(() => console.log('Database ready!'))
    .catch(err => console.log('Internal Server Error - 500'));

app.get('/', (req, res) => {
     res.sendFile(path.join(__dirname, '/views/home.html'));
});

app.listen(port, () => console.log(`Server is listening on post ${port}...`));

